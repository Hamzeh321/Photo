import React from 'react';
import { Upload, Image as ImageIcon, Download, Star, Code, Smartphone, ChevronRight } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <ImageIcon className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">BackgroundAI</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#tools" className="text-gray-700 hover:text-blue-600">Tools</a>
              <a href="#api" className="text-gray-700 hover:text-blue-600">API</a>
              <a href="#blog" className="text-gray-700 hover:text-blue-600">Blog</a>
              <a href="#pricing" className="text-gray-700 hover:text-blue-600">Pricing</a>
            </nav>
            <div className="flex items-center space-x-4">
              <button className="text-gray-700 hover:text-blue-600">Log in</button>
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                Sign up
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl md:text-6xl mb-4">
            Free Image Background Remover
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Remove image backgrounds automatically in seconds with our AI-powered tool. 
            Keep it transparent or add a new background - all for free.
          </p>
        </div>

        {/* Upload Section */}
        <div className="max-w-3xl mx-auto mb-16">
          <div className="bg-white rounded-xl shadow-lg p-8 border-2 border-dashed border-blue-200 hover:border-blue-400 transition-colors">
            <div className="text-center">
              <Upload className="h-16 w-16 text-blue-600 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Drag and drop your image here
              </h3>
              <p className="text-gray-500 mb-4">
                or click to upload (JPG, PNG, or HEIC)
              </p>
              <button className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors">
                Remove Background
              </button>
            </div>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <TrustCard
            icon={<Star className="h-8 w-8 text-yellow-400" />}
            title="Trusted by millions"
            description="Over 30 million people use our tools"
          />
          <TrustCard
            icon={<Code className="h-8 w-8 text-blue-600" />}
            title="Developer API"
            description="Integrate background removal into your app"
          />
          <TrustCard
            icon={<Smartphone className="h-8 w-8 text-green-600" />}
            title="Mobile Apps"
            description="Available on iPhone & Android"
          />
        </div>

        {/* How It Works */}
        <div className="bg-blue-50 rounded-2xl p-8 mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            How to Remove Background from a Picture
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <StepCard
              number="1"
              icon={<Upload className="h-6 w-6" />}
              title="Upload Image"
              description="Upload any JPG, PNG, or HEIC image"
            />
            <StepCard
              number="2"
              icon={<ImageIcon className="h-6 w-6" />}
              title="Auto Processing"
              description="Our AI removes the background instantly"
            />
            <StepCard
              number="3"
              icon={<Download className="h-6 w-6" />}
              title="Download"
              description="Get your image with transparent background"
            />
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <button className="inline-flex items-center justify-center space-x-2 bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors">
            <span>Try it now - it's free</span>
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-50 mt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase mb-4">
                Product
              </h3>
              <ul className="space-y-4">
                <li><a href="#features" className="text-gray-600 hover:text-blue-600">Features</a></li>
                <li><a href="#pricing" className="text-gray-600 hover:text-blue-600">Pricing</a></li>
                <li><a href="#api" className="text-gray-600 hover:text-blue-600">API</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase mb-4">
                Company
              </h3>
              <ul className="space-y-4">
                <li><a href="#about" className="text-gray-600 hover:text-blue-600">About</a></li>
                <li><a href="#blog" className="text-gray-600 hover:text-blue-600">Blog</a></li>
                <li><a href="#careers" className="text-gray-600 hover:text-blue-600">Careers</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase mb-4">
                Support
              </h3>
              <ul className="space-y-4">
                <li><a href="#help" className="text-gray-600 hover:text-blue-600">Help Center</a></li>
                <li><a href="#contact" className="text-gray-600 hover:text-blue-600">Contact</a></li>
                <li><a href="#status" className="text-gray-600 hover:text-blue-600">Status</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase mb-4">
                Legal
              </h3>
              <ul className="space-y-4">
                <li><a href="#privacy" className="text-gray-600 hover:text-blue-600">Privacy</a></li>
                <li><a href="#terms" className="text-gray-600 hover:text-blue-600">Terms</a></li>
                <li><a href="#security" className="text-gray-600 hover:text-blue-600">Security</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-12 border-t border-gray-200 pt-8">
            <p className="text-center text-gray-400">
              © {new Date().getFullYear()} BackgroundAI. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function TrustCard({ icon, title, description }: { icon: React.ReactNode;title: string;description: string }) {
  return (
    <div className="flex flex-col items-center text-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
      <div className="mb-4">{icon}</div>
      <h3 className="text-lg font-medium text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-500">{description}</p>
    </div>
  );
}

function StepCard({ number, icon, title, description }: {
  number: string;
  icon: React.ReactNode;
  title: string;
  description: string
}) {
  return (
    <div className="flex items-start space-x-4">
      <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
        {number}
      </div>
      <div>
        <div className="flex items-center space-x-2 mb-2">
          <div className="text-blue-600">{icon}</div>
          <h3 className="font-medium text-gray-900">{title}</h3>
        </div>
        <p className="text-gray-500">{description}</p>
      </div>
    </div>
  );
}

export default App;